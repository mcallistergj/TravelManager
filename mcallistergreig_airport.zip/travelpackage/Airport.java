package travelpackage;
public class Airport {

	private String name;
	
	Airport(String name){
		this.name = name;
	}
	
	public String getName(){
		return this.name;
	}
	
}
