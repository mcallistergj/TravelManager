package travelpackage;

public class Port extends Terminal {

		
		public Port(String name){
			this.name = name;
		}
		
		public String getName(){
			return this.name;
		}
		
}
