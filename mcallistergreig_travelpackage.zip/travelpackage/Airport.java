package travelpackage;
public class Airport extends Terminal{


	
	Airport(String name){
		this.name = name;
	}
	
	public String getName(){
		return this.name;
	}
	


}
