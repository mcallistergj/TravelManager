package travelpackage;

import java.util.Scanner;

public class MenuUtil {

	SystemManager sysMan = new SystemManager();
	
	public void mainMenu(){
		
	}
	
	public void adminMenu(){
		int choice;
		Scanner kb = new Scanner(System.in);
		do{
			System.out.println("Enter desired option:");
			System.out.println("1.) Open Air Travel Menu.");
			System.out.println("2.) Open Cruise Menu.");
			System.out.println("3.) Print Air Travel Information.");
			System.out.println("4.) Print Cruise Information.");
			System.out.println("5.) Return to main menu.");
			choice = kb.nextInt();
			switch(choice){
				case 1: 
					airMenu();
					break;
				case 2:
					cruiseMenu();
					break;
				case 3:
					System.out.println("Displaying Air info");
					break;
				case 4:
					System.out.println("Displaying Cruise info");
					break;
			}
		}while(choice != 5);
	}
	
	public void airMenu(){
		
	}
	
	public void cruiseMenu(){
		
	}
	
	public void userMenu(){
		int choice;
		String airline,flight;
		Scanner kb = new Scanner(System.in);
		do{
			System.out.println("Please select what you would like to do:");
			System.out.println("1.) Initialize airport system.");
			System.out.println("2.) Change seat prices in a flight section.");
			System.out.println("3.) Look up flights with available seats.");
			System.out.println("4.) Change pricing of given seat class.");
			System.out.println("5.) Book a specific seat on a given flight.");
			System.out.println("6.) Book a seat given a seating preference.");
			System.out.println("7.) Display Airport System Details.");
			System.out.println("8.) Store Airport System Details to file.");
			System.out.println("9.) Enter Admin Menu.");
			System.out.println("10.) Exit the system.");
			choice = kb.nextInt();
			switch(choice){
				case 1: 
					System.out.println("Airport System initialized.");
					break;
				case 2:
					System.out.println("Not funtional yet");
					break;
				case 3:
					System.out.println("Not functional yet");
					break;
				case 4:
					System.out.println("Not functional yet");
					break;
				case 5:
					System.out.println("Not functional yet");
					break;
				case 6:
					System.out.println("Not functional yet");
					break;
				case 7:
					sysMan.displaySystemDetails();
					break;
				case 8:
					System.out.println("Not functional yet");
					break;
				case 9:
					adminMenu();
			}
			
			
		}while(choice != 10);
		kb.close();
	}
	
}
