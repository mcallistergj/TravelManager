package travelpackage;

public class CabinSection extends Section {

}
