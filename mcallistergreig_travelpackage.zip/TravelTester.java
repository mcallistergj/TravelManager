import travelpackage.*;

import java.util.*;
import java.io.*;



public class TravelTester{
	
	public static void main(String[] args) throws FileNotFoundException{
		SystemManager sm = new SystemManager();
		sm.menu();
	}
}
